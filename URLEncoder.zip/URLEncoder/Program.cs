﻿using System;

namespace URLEncoder
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Write("URL Encoder --- ");
                Console.Write("What is your project name?: ");
                string projectName = Program.GetUserInput();
                Console.Write("What is your activity name?: ");
                string activityName = Program.GetUserInput();
                Console.Write("Your new URL: ");
                Console.Write(CreateURL(projectName, activityName));
                Console.Write("\r\n");
                Console.Write("Would you like to do another? (y/n): ");
            } while (Console.ReadLine().ToLower().Equals("y"));
        }
        //Test User Input
        static bool IsValid(string input)
        {
            if (input.Contains("NUL") || input.Contains("SOH") || input.Contains("STX")
            || input.Contains("ETX") || input.Contains("EOT") || input.Contains("ENQ")
            || input.Contains("ACK") || input.Contains("BEL") || input.Contains("BS")
            || input.Contains("HT") || input.Contains("LF") || input.Contains("VT")
            || input.Contains("FF") || input.Contains("CR") || input.Contains("SO")
            || input.Contains("SI") || input.Contains("DLE") || input.Contains("DC1")
            || input.Contains("DC2") || input.Contains("DC3") || input.Contains("DC4")
            || input.Contains("NAK") || input.Contains("SYN") || input.Contains("ETB")
            || input.Contains("CAN") || input.Contains("EM") || input.Contains("SUB")
            || input.Contains("ESC") || input.Contains("FS") || input.Contains("GS")
            || input.Contains("RS") || input.Contains("US")) return false;
            else return true;
        }
        //Compile URL
        static string CreateURL(string projectName, string activityName)
        {
            string newURL = "https://companyserver.com/content/" + projectName + "/files/" + activityName + "/" + activityName + "Report.pdf";
            return newURL;
        }
        //Collect User Input
        static string GetUserInput()
        {
            string input = "";
            do
            {
                input = Console.ReadLine();
                //Embedded Encoder
                if (IsValid(input))
                {
                    if(input.Contains(";") || input.Contains("/") || input.Contains("?")
                    || input.Contains(":") || input.Contains("@") || input.Contains("&")
                    || input.Contains("=") || input.Contains("+") || input.Contains("$")
                    || input.Contains(",") || input.Contains("{") || input.Contains("}")
                    || input.Contains("|") || input.Contains("[") || input.Contains("]")
                    || input.Contains("^") || input.Contains("'") || input.Contains(" "))
                    {
                        input = input.Replace(";", "%3B");
                        input = input.Replace("/", "%2F");
                        input = input.Replace("?", "%3F");
                        input = input.Replace(":", "%3A");
                        input = input.Replace("@", "%40");
                        input = input.Replace("&", "%26");
                        input = input.Replace("=", "%3D");
                        input = input.Replace("+", "%2B");
                        input = input.Replace("$", "%24");
                        input = input.Replace(",", "%2C");
                        input = input.Replace("{", "%7B");
                        input = input.Replace("}", "%7D");
                        input = input.Replace("|", "%7C");
                        input = input.Replace("[", "%5B");
                        input = input.Replace("]", "%5D");
                        input = input.Replace("'", "%60");
                        input = input.Replace(" ", "%20");
                        input = input.Replace("^", "%5E");
                        return input;
                    }
                    else return input;
                }
                Console.Write("The input contains invalid characters. ");
            }   while (true);
        }
    }
}

